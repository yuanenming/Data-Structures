#include <iostream>
using namespace std;
//设计一个函数，将任意一个最小化堆中最小的三个元素调整到一、二层
template<class Type>
class priorityQueue
{
public:
	priorityQueue(int capacity = 100)
	{
		array = new Type[capacity];
		maxSize = capacity;
		currentSize = 0;
	}
	priorityQueue(const Type data[],int size);
	~priorityQueue(){delete []array;}

	bool isEmpty()const{return currentSize == 0;}
	void enQueue(const Type &x);
	Type deQueue();
	Type getHead()const{return array[1];}
	void sort123();
private:
	int currentSize;
	Type *array;
	int maxSize;
	void doubleSpace();
	void buildHeap();
	void percolateDown( int hole );
};

template<class Type>
void priorityQueue<Type>::enQueue(const Type &x)
{
	if(currentSize == maxSize-1)doubleSpace();
	int hole = ++ currentSize;
	for(;hole>1&&x<array[hole/2];hole/=2)
		array[hole] = array[hole/2];
	array[hole] = x;
}

template<class Type>
Type priorityQueue<Type>::deQueue()
{
	Type minItem;
	minItem = array[1];
	array[1] = array[currentSize --];
	percolateDown(1);
	return minItem;
}

template<class Type>
void priorityQueue<Type>::percolateDown(int hole)
{
	int child;
	Type tmp = array[hole];
	for(;hole*2<= currentSize;hole=child)
	{
		child = hole*2;
		if(child!=currentSize && array[child+1]<array[child])
			child ++;
		if(array[child]<tmp)array[hole] = array[child];
		else break;
	}
	array[hole] = tmp;
}

template <class Type>
void priorityQueue<Type>::buildHeap()
{
	for(int i = currentSize/2;i>0;i--)
		percolateDown(i);
}

template<class Type>
priorityQueue<Type>::priorityQueue(const Type *items,int size):maxSize(size+10),currentSize(size)
{
	array = new Type[maxSize];
	for (int i=0;i<size;i++)array[i+1] = items[i];
	buildHeap();
}

template<class Type>
void priorityQueue<Type>::doubleSpace()
{
	Type *tmp = array;
	maxSize *= 2;
	array = new Type [maxSize];
	for(int i=0;i<=currentSize;++i)
	{
		array[i] = tmp[i];
	}
	delete []tmp;
}
template <class Type>
void priorityQueue<Type>::sort123()
{
	Type tmp;
	if (currentSize < 3) cout<<"currentSize is less than 3"<<endl;
	else
	{
		tmp = array[3];
		array[3] = array[2];
		array[2] = tmp;
		percolateDown(2);
		percolateDown(3);
		cout<<"The minimum 3 are"<<array[1]<<" "<<array[2]<<" "<<array[3]<<endl;
	}
}
int main()
{
	int a[] = {2,3,10,5,11,12,1};
	priorityQueue<int> que(a,7);
	que.sort123();
	while(!que.isEmpty())
	{
		cout<<que.deQueue()<<endl;
	}
	return 0;
}