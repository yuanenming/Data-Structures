#include <iostream>
#include <list>
#include <queue>
using namespace std;

template <class Type>
class BinaryTree
{
private:
	struct Node{
		Node *left, *right;
		Type data;
		Node():left(NULL),right(NULL){}
		Node(Type item,Node *L = NULL, Node *R = NULL):
		data(item),left(L),right(R){}
		~Node(){}
	};
	Node * root;

public:
	BinaryTree():root(NULL){}
	BinaryTree(const Type &value){root = new Node(value);}
	~BinaryTree(){clear();}

	Type getRoot() const{return root -> data;}
	Type getLeft() const{return root ->left -> data;}
	Type getRight() const{return root ->right -> data;}

	void makeTree(const Type &x, BinaryTree &lt, BinaryTree &rt)
	{
		root = new Node(x, lt.root, rt.root);
		lt.root = NULL;
		rt.root = NULL;
	}

	void deLeft()
	{
		BinaryTree tmp = root -> left;
		root -> left = NULL;
		tmp.clear();
	}

	void deRight()
	{
		BinaryTree tmp = root -> right;
		root -> right = NULL;
		tmp.clear();
	}
	bool isEmpty() const {return root == NULL;}
	void clear(){if(root != NULL) clear(root);root = NULL;}
	int size()const{return size(root);}

	bool isEqual(BinaryTree x)const
	{
		return isEqual(root, x.root);
	}

	void createTree(Type flag)
	{
		queue<Node *>que;
		Node * tmp;
		Type x, ldata, rdata;
		cout<<"\n 输入根节点：";
		cin >> x;
		root = new Node(x);
		que.push(root);
		while(!que.empty())
		{
			tmp = que.front();
			que.pop();
			cout<<"\n输入"<<tmp->data<<"的两个儿子：（"<<flag<<"表示空节点):";
			cin >> ldata >> rdata;
			if(ldata != flag) que.push(tmp->left = new Node(ldata));
			if(rdata != flag) que.push(tmp->right = new Node(rdata));
		}
		cout<<"create completed!"<<endl;
	}
private:
	void clear(Node *t)
	{
		if(t->left != NULL)
			clear(t->left);
		if(t->right != NULL)
			clear(t->right);
		delete t;
	}

	int size(Node *t)const
	{
		if(t==NULL)return 0;
		return 1+size(t->left) + size(t->right);
	}

	bool isEqual(Node *t1, Node*t2)const
	{
		if(t1==NULL && t2==NULL) return true;
		if(t1==NULL || t2==NULL) return false;
		if(t1 -> data != t2 ->data) return false;
		return isEqual(t1->left,t2->left)&&isEqual(t1->right,t2->right);
	}
};

int main()
{
	BinaryTree<char> tree, tree1;
	tree.createTree('@');
	tree1.createTree('@');
	bool equal = tree.isEqual(tree1);
	if(equal)
	    cout<<"They are equal!"<<endl;
	else cout<<"They are Not equal!"<<endl;
	return 0;

}