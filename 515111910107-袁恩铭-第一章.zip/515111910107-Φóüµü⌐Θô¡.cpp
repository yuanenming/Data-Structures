#include <iostream>
using namespace std;

int main()
{
	int n, sum;
	cout<<"Calculate S = 1-2+3-4+5-...+/-N"<<endl<<"N = ";
	cin>>n;
	if(n > 0)
	{
		if (n%2) sum = (n+1)/2;
		else sum = -n/2;
		cout<<"S="<<sum<<endl;
	}
	else
	{
		cout<<"Illague Value!";
		exit(1);
	}
	return 0;
}
