#include <iostream>
using namespace std;

//队列的抽象类
template<class elemType>
class queue
{
	public:
	virtual bool isEmpty() = 0;
	virtual void Push(const elemType &x) = 0;
	virtual elemType Pull() = 0;
	virtual elemType getHead() = 0;
	virtual ~queue(){}
};

template<class elemType>
class circleQueue:public queue<elemType>
{
	private:
		struct node
		{
			elemType data;
			node *next;
			node(const elemType &x, node *N = NULL){data = x; next = N;}
			node():next(NULL){}
		    ~node(){}
		};
		node *tail;
	public:
		circleQueue(){tail=NULL;}
		~circleQueue();
		bool isEmpty(){return tail == NULL;}
		void Push(const elemType &x);
		elemType Pull();
		elemType getHead(){return tail->next->data;}
};

template<class elemType>
void circleQueue<elemType>::Push(const elemType &x)
{
	node *tmp;
	if(tail == NULL)
	{
		tail = new node(x);
	}
	else if(tail->next == NULL)
	{
		tmp = new node(x,tail);
		tail->next = tmp;
		tail = tail->next;
	}
	else
	{
		tmp = new node(x,tail->next);
		tail->next = tmp;
		tail = tail->next;
	}
}
template<class elemType>
elemType circleQueue<elemType>::Pull(){
	node *tmp = tail->next;
	elemType value = tmp->data;
	if(tmp == tail)
	{
		delete tmp;
		tail = NULL;
	}
	else
	{
		tail->next = tmp->next;
		delete tmp;
	}
	return value;
}
template<class elemType>
circleQueue<elemType>::~circleQueue()
{
	node *tmp;
	while(tail != NULL)
	{
		tmp = tail->next;
		tail->next = tmp->next;
		delete tmp;
	}
}

int main()
{
	circleQueue<char> Q;
	char in;
	cout<<"Please input a character(! to stop):";
	cin>>in;
	while(in != '!')
	{
		Q.Push(in);
		cout<<"Please input a character(! to stop):";
	    cin>>in;
	}
	cout<<"OUTPUT:"<<endl;
	while(!Q.isEmpty())
	{
		cout<<Q.Pull()<<endl;
	}
	return 0;
}