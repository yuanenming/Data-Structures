#include <iostream>
using namespace std;

//栈的抽象类
template <class elemType>
class stack
{
public:
	virtual bool isEmpty() const = 0;
	virtual void push(const elemType &x) = 0;
	virtual elemType pop() = 0;
	virtual elemType top() const = 0;
	virtual ~stack(){}
};
template <class elemType>
class seqStack:public stack <elemType>
{
private:
	elemType * elem;
	int top_p;
	int maxsize;
	void doubleSpace()
	{
       elemType * tmp = elem;
       elem = new elemType[2*maxsize];
       for ( int i = 0; i < maxsize; ++i)
       	elem[i] = tmp[i];
       maxsize *= 2;
       delete []tmp;
    }

public:
	seqStack(int initSize = 10)
	{
		elem = new elemType[initSize];
		maxsize = initSize;
		top_p = -1;
	}

	~seqStack()
	{
		delete []elem;
	}

	bool isEmpty() const {return top_p == -1;}

	void push(const elemType &x)
	{
		if(top_p == maxsize - 1)doubleSpace();
		elem[++top_p] = x;
	}

	elemType pop(){return elem[top_p--];}

	elemType top() const{return elem[top_p];}

};

//主函数
int main()
{
	int input;
	seqStack <int> output;
	cout<<"请输入要处理的10进制正数："<<endl;
	cin>>input;
	//将十进制数除以二，然后余数进栈，直至不能除不开
    while(input)
    {
    	output.push(input%2);
    	input /= 2;
    }
    cout<<"转化为的二进制数为：";
    while(!output.isEmpty()) cout<<output.pop();
    cout<<endl;
    return 0;
}