# include <iostream>
using namespace std;
template <class ElemType>
class Linklist
{
private:
	struct Node{
		ElemType Data;
		Node * Next;
	    Node(const ElemType &x, Node *p = NULL)
	    {
	    	Data = x;
	        Next = p;
	    }
	    Node():Next(NULL){};
	    ~Node(){};
	};
    Node *head;
public:
	Linklist(){head = new Node;}
	~Linklist(){clear(), delete head;} //析构函数
	void clear()    //清空函数
	{
		Node * p = head->Next, *q;
		while(p != NULL)
		{
            q = p->Next;
            delete p;
            p = q;
		}
		head->Next = NULL;
	}
	void insert(int i, const ElemType &x) //在第i个位置插入一个数据
	{
        Node *p = head,*tmp;
        while(i--)p = p->Next;
        tmp = new Node(x, p->Next);
        p->Next = tmp;
	}
	int lastk(int k)   //寻找倒数第k个数据，当移动到第k个之后，两个指针一起移动，当后面一个移动到链表的尾，前面一个正好是倒数第k个。
	{
		int i = k;
		Node *p = head, *q = head;
        while(--i)
        {
            if(p->Next) p = p->Next;
            else{cout<<"Out of boundary!"<<endl;return 0;}
        }
        while(p->Next)
        {
            p = p->Next;
            q = q->Next;
        }
        cout<<q->Data<<endl;
        return 1;
	}
};

int main()
{
	Linklist<int> list;
	for(int i = 0; i <= 10; ++i) list.insert(i, i);
	list.lastk(5);
    cout<<list.lastk(20);
    return 0;
}